/**********************************************************************
 * NewCar.java
 * By Crystal Peng
 * HW, CS219
 * (shell code, 3 ADDs)
 *
 * A class for NewCar. Extends Car class
 **********************************************************************/
package dealership;

public class NewCar extends Car {
  private int instantSavings; // discount on a new car

  //***************************************************

  // constructor
  public NewCar(String stockID, int year, String model, String bodyStyle,
      String color, int cityMpg, int highwayMpg, int price,
      int instantSavings) {
    // ADD CODE #1
    super(stockID, year, model, bodyStyle, color, cityMpg, highwayMpg, price);
    this.instantSavings = instantSavings;
  } // end constructor

  //***************************************************

  // accessor: getXXX
  public int getInstantSavings() {
    return instantSavings;
  }

  //***************************************************

  // overrides equals method of Object
  public boolean equals(Object obj) {
    // ADD CODE #2: remove the fake return line
    {
      return super.equals(obj) && (obj instanceof NewCar) && instantSavings == ((NewCar) obj).instantSavings;
      // yes obj is a Car object
          
    }
    } // end equals

  //***************************************************

  // overrides toSting method of Object
  public String toString() {
    // ADD CODE #3: remove the fake return line
    return super.toString()+ "\n" +"instant Savings: "+ instantSavings;
  } // end toString

} // end class NewCar

