package dealership;

public abstract class Car {
  private String stockID;
  private int    year;
  private String model;
  private String bodyStyle;
  private String color;
  private int    cityMpg;
  private int    highwayMpg;
  private int    price; // MSRP for new car; price for used car

  //***************************************************

  public Car(String stockID, int year, String model, String bodyStyle,
      String color, int cityMpg, int highwayMpg, int price) {
    this.stockID = stockID;
    this.year = year;
    this.model = model;
    this.bodyStyle = bodyStyle;
    this.color = color;
    this.cityMpg = cityMpg;
    this.highwayMpg = highwayMpg;
    this.price = price;
  } // end constructor

  //***************************************************

  // accessors: getXXX()
  public String getStockId() {
    return stockID;
  }

  public int getYear() {
    return year;
  }

  public String getModel() {
    return model;
  }

  public String getBodyStyle() {
    return bodyStyle;
  }

  public String getColor() {
    return color;
  }

  public int getCityMpg() {
    return cityMpg;
  }

  public int getHighwayMpg() {
    return highwayMpg;
  }

  public int getPrice() {
    return price;
  }

  //***************************************************

  // overrides equals method of Object
  public boolean equals(Object obj)
  {
    if (this == obj) // self comparison
      return true;

    if (! (obj instanceof Car)) // null obj or not Car type
      return false;

    // yes obj is a Car object
    Car carObj = (Car) obj; // type cast
    return stockID.equals(carObj.stockID) &&
        year == carObj.year &&
        model.equals(carObj.model) &&
        bodyStyle.equals(carObj.bodyStyle) &&
        color.equals(carObj.color) &&
        cityMpg == carObj.cityMpg &&
        highwayMpg == carObj.highwayMpg &&
        price == carObj.price;
  } // end equals

  //***************************************************

  // overrides toSting method of Object
  public String toString() {
  return "Stock ID: " + stockID + "\n" +
      year + " " +
      model + " " +
      bodyStyle + "\n" +
      "Color:\t" + color + "\n" +
      "MPG:\t" + cityMpg + "/" + highwayMpg + "\n" +
      "Price:\t$" + price;
  } // end toString

} // end class Car
