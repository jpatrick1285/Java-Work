/**********************************************************************
 * UsedCar.java
 * By Crystal Peng
 * HW6, CS219
 *
 * A class for UsedCar. Extends Car class
 **********************************************************************/
package dealership;

public class UsedCar extends Car {
  private int mileage;

  //***************************************************

  // constructor
  public UsedCar(String stockID, int year, String model, String bodyStyle,
        String color, int cityMpg, int highwayMpg, int price,
        int mileage) {
    super(stockID, year, model, bodyStyle,
        color, cityMpg, highwayMpg, price);
    this.mileage = mileage;
  } // end constructor

  //***************************************************

  // accessor: getXXX
  public int getMileage() {
    return mileage;
  }

  //***************************************************

  // overrides equals method of Object
  public boolean equals(Object obj) {
    return super.equals(obj) &&
      (obj instanceof UsedCar) &&
      mileage == ((UsedCar) obj).mileage;
  } // end equals

  //***************************************************

  // overrides toSting method of Object
  public String toString() {
    return super.toString() + "\n" +
      "Mileage: " + mileage;
  } // end toString

} // end class UsedCar
