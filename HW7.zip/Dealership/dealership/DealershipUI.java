/* DealershipUI.java
 * By Crystal Peng
 * HW, CS219
 * (shell code, 2 ADDs, 1 EC ADD)
 *
 * User interface class for dealership project. All user interaction
 * happens in this class
 * 1. provides main menu screen and sub menu screens for different
 *    search options
 * 2. process user search requests by calling corresponding methods
 *    of Dealership object
 *********************************************************************/
package dealership;
import java.util.ArrayList; // ArrayList results from Dealership
import java.util.Scanner; // user I/O

public class DealershipUI {
  // constant strings used in all menu screens
  private final String SEPARATOR = "-------------------------------------\n";
  private final String SEARCH_TITLE_STR = "Search options:\n";
  private final String NO_MATCH_STR = "No matching results.\n";

  //***************************************************
  private Dealership ds;  // dealership object this UI works with
  private Scanner stdIn = new Scanner(System.in); // set up keyboard input

  //***************************************************

  // constructor
  public DealershipUI(Dealership ds)
  {
    this.ds = ds;
  } // end constructor

  //***************************************************

  // main screen
  public void startMainScreen()
  {
    final String HEADER_STR = "Welcome to " + ds.getDealerName() + "\n"; // header string

    final String[] SEARCH_OPTION_STRS = {"1. New Cars (" + ds.getNumNewCars() + "): by model\n",
      "2. Used Cars ("+ ds.getNumUsedCars() + "): by year\n",
      "3. Used Cars ("+ ds.getNumUsedCars() + "): by price\n",
      "0. Exit\n"
      }; // main menu search options
    final int NUM_MENU_OPTIONS = SEARCH_OPTION_STRS.length;
    final String SEARCH_PROMPT_STR = "Please enter 0-" + (NUM_MENU_OPTIONS-1) + ": ";

    // bye-bye message
    final String BYE_STR = "Thanks for visiting " + ds.getDealerName() + ". See you again soon!\n";

    final String INVALID_OPTION_STR = "Invalid option. " + SEARCH_PROMPT_STR;

    final int EXIT_OPTION = 0; // 0 for Exit Option

    // loop to interact with user: multiple searches
    int userOption = EXIT_OPTION; // default Exit
    do {
      // multiple search sessions: only display menu again if previous session was valid option
      if (userOption >= 0 && userOption < NUM_MENU_OPTIONS) // valid option selected in previous session
      {
        // 0. clear console print
        clearScreen();

        // 1. display menu
        display(HEADER_STR); // main header
        display(SEPARATOR);
        display(SEARCH_TITLE_STR);
        for (String str : SEARCH_OPTION_STRS)
          display(str);
        display(SEARCH_PROMPT_STR);
      }

      // 2. user input
      userOption = stdIn.nextInt();

      // 3. respond
      switch (userOption) {
      case 1: // new car search: by model
        // model sub menu screen
        startNewCarModelSubScreen();
        break;
      case 2: // used car search: by year
        startUsedCarYearSubScreen();
        break;
      case 3: // used car search: by price
        startUsedCarPriceSubScreen();
        break;
      case EXIT_OPTION: // exit
        display(BYE_STR);  // display bye-bye message
        break;
      default:  // invalid option
        display(INVALID_OPTION_STR);
      } // end switch
    } while (userOption != EXIT_OPTION);  // end loop to interact with user

  } // end startMainScreen

  //***************************************************

  // search new car by model sub menu screen
  private void startNewCarModelSubScreen()
  {
    // a list of all models seen in new cars. Will use as menu options
    ArrayList<String> allNewCarModels = ds.getAllNewCarModels();

    // constants used
    final int NUM_NEW_CAR_MODELS = allNewCarModels.size(); // # of models of new cars
    final int NUM_MENU_OPTIONS = NUM_NEW_CAR_MODELS + 1; // # of models + back to main option

    // other menu messages
    final String TO_MAIN_OPTION_STR = "0. Back to main search menu\n";
    final String SEARCH_PROMPT_STR = "Please enter 0-" + (NUM_MENU_OPTIONS - 1) + ": ";
    final String INVALID_OPTION_STR = "Invalid option. " + SEARCH_PROMPT_STR;

    // loop to interact with user: allow multiple search sessions
    final int EXIT_OPTION = 0; // 0 for Back to main menu Option
    int userOption = EXIT_OPTION; // default back to main
    do {
      // multiple search sessions: display menu again only if previous session was valid option
      if (userOption >= 0 && userOption < NUM_MENU_OPTIONS) // valid option from previous session
      {
        // 1. display menu
        display("\n\nMain -> Search New Cars (" + ds.getNumNewCars() + ") - by Model\n"); // header
        display(SEPARATOR);
        display(SEARCH_TITLE_STR);
        for (int i=0; i<NUM_NEW_CAR_MODELS; i++)
          display((i+1) + ". " + allNewCarModels.get(i) + "\n");
        display(TO_MAIN_OPTION_STR);
        display(SEARCH_PROMPT_STR);
      }

      // 2. user input
      userOption = stdIn.nextInt();

      // 3. respond
      if (userOption == EXIT_OPTION) // exit: back to main
      {
        // no display. back to main menu by ending this method
        return;
      }
      else if (userOption>0 && userOption<NUM_MENU_OPTIONS)  // valid: one of the models selected
      {
        // 3.1 find new cars of that model
        ArrayList<Car> allCars = ds.getAllCars(); // retrieve all cars from dealership object
        String targetModel = allNewCarModels.get(userOption - 1); // model to search for

        ArrayList<Car> foundCars = new ArrayList<Car>(); // store search results

        // ADD CODE #6:
        // loop through all cars (in local variable ArrayList<Car> object allCars)
        //   add to foundCars if a matching new car (its model matches the targetModel string)

        for(int i = 0; i < allCars.size(); i++)
        {
          if(allCars.get(i).getModel().equals(targetModel))
          {
            foundCars.add(allCars.get(i));
          }
        }
        // 3.2 list results
        if (foundCars.isEmpty()) // no matching cars
        {
          display(NO_MATCH_STR);
        }
        else // found matching cars
        {
          //ADD CODE #7
          System.out.println("Found matching cars: " + foundCars.size() + " (Model: " + targetModel + ")");
          // display a leading separator line
          System.out.println(SEPARATOR);
          // display all car in foundCars, one blank line between each car
          for(Car x: foundCars)
          {
            System.out.println(x);
          }
          // display a trailing separator line
          System.out.println(SEPARATOR);
        }
      } // end else if valid user option
      else // invalid options
      {
        display(INVALID_OPTION_STR);
      } // end if-else: respond to user options
    } while (true);  // end loop to interact with user

  } // end startNewCarModelSubScreen

  //***************************************************

  // search used car by year sub menu screen
  private void startUsedCarYearSubScreen()
  {
    final String SEARCH_PROMPT_STR = "Please enter year range or 0 to go back to main menu: ";
    final String INVALID_OPTION_STR = "Invalid option. " + SEARCH_PROMPT_STR;

    // loop to interact with user: multiple searches
    final int EXIT_OPTION = 0; // 0 for Back to main menu Option
    do {
      // 1. display menu
      display("\n\nMain -> Search Used Cars (" + ds.getNumUsedCars() + ") - by Year\n"); // header
        display(SEPARATOR);

      // 2. user input: start year, end year
      display("  start_year (enter 0 to go back to main menu): ");
      int startYear = stdIn.nextInt();
      if (startYear == EXIT_OPTION)
      break;  // break out of while loop - back to main

      display("  end_year (enter 0 to go back to main menu): ");
      int endYear = stdIn.nextInt();

      // 3. respond
      if (endYear == EXIT_OPTION) // exit: back to main
      {
        // no display. back to main menu by ending this method
        break;
      }
      else if (startYear <= endYear)// valid year range
      {
        // 3.1 search for all used cars of in the year range
        ArrayList<Car> allCars = ds.getAllCars();
        ArrayList<Car> foundCars = new ArrayList<Car>(); // store search results
        for (Car c : allCars) // loop through all cars
        {
          if ((c instanceof UsedCar) &&
              c.getYear() >= startYear &&
            c.getYear() <= endYear) // match
          {
            foundCars.add(c);
          }
        } // end loop through all cars

        // 3.2 display results
        if (foundCars.isEmpty()) // no matching cars
        {
          display(NO_MATCH_STR);
        }
        else // found matching cars
        {
          display("\nFound matching cars: " + foundCars.size() + " (Year range: " + startYear + " - " + endYear + ")\n");
          display(SEPARATOR);
          for (Car c : foundCars)
          {
            display(c + "\n\n"); // dynamic binding will use correct toString here
          }
          display(SEPARATOR);
        }

      } // end else-if valid year range
      else // invalid years
      {
        display(INVALID_OPTION_STR);
      } // end if-else: respond to user options

    } while (true);  // end loop to interact with user

  } // end startUsedCarYearSubScreen

  //***************************************************

  // search used car by price
  private void startUsedCarPriceSubScreen()
  {
    final String SEARCH_PROMPT_STR = "Please enter price range or 0 to go back to main menu: ";
    final String INVALID_OPTION_STR = "Invalid option. " + SEARCH_PROMPT_STR;

    // loop to interact with user: multiple searches
    final int EXIT_OPTION = 0; // 0 for Back to main menu Option

    // (Extra Credit) ADD CODE #8: remove fake display below: display("fake\n");
    /* loop to get user inputs to search for price range.
       similar to startUsedCarYearSubScreen().
       Study sample output and startUsedCarYearSubScreen() for what should happen here.
    */
    display("fake\n");


  } // end startUsedCarPriceSubScreen

  //***************************************************

  // a helper method to simulate clearing screen by printing multiple blank lines
  private static void clearScreen()
  {
    for (int i=0; i<20; i++)
      System.out.println();
  } // end clearScreen

  //***************************************************

  // a helper method to display a string on screen
  private static void display(String str)
  {
    System.out.print(str);
  } // end display

} // end class DealershipUI
