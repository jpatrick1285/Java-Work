/**********************************************************************
 * DealershipUIDriver.java
 * By Crystal Peng
 * HW, CS219 Fall 2015
 *
 * Driver code for DealershipUI project
 *********************************************************************/
package dealership;
public class DealershipUIDriver {
  public static void main(String[] args)
  {
    Dealership ds = new Dealership("Awesome Ford - Kansas City", "data/inventory.csv"); // create a new dealership object using inventory data in data/inventory.csv

    DealershipUI dsui = new DealershipUI(ds); // create a new DealershipUI object and pass in dealership object
    dsui.startMainScreen(); // start main screen
  } // end main
} // end class DealershipUIDriver