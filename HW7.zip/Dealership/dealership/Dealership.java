package dealership;
/**********************************************************************
 /* Dealership.java
 * By Crystal Peng
 * HW, CS219
 * (shell code, 2 ADDs)
 *
 * A class for loading car inventory records from file and generate
 * report.
 * 1. loads data of car inventory records from a csv file which stores
 *   new and used car information, and
 * 2. generate some basic statistics which will be used by outsiders
 *********************************************************************/

// java.io classes, used for file i/o
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.util.ArrayList;  // used to provide result to outsiders

import java.util.Scanner; // I/O methods

public class Dealership {
  private final int MAX_SIZE = 100;  // max # of cars a dealership can carry
                                     // used to define inventory array

  //***************************************************

  // dealership data
  private String dealerName; // dealership name

  // raw data: car inventory record data from csv file
  private Car[] inventory; // array of cars
  private int totalNumCars;   // track total # of cars in inventory

  // report data
  private int numNewCars; // track # of new cars in inventory
  private int numUsedCars; // track # of used cars in inventory
  private ArrayList<String> allNewCarModels; // list all new car models. used in new car search

  //***************************************************

  // constructor:
  // 1. load raw inventory data from file into array,
  // 2. count # of new and used cars
  public Dealership(String dealerName, String dataFileName)
  {
    this.dealerName = dealerName;

    inventory = new Car[MAX_SIZE]; // create inventory array object
    totalNumCars = loadFromFile(dataFileName);

    generateReportData();
  }

  //***************************************************

  // accessors: getXXX
  public String getDealerName() {
    return dealerName;
  }

  public int getTotalNumCars() {
    return totalNumCars;
  }

  public int getNumNewCars() {
    return numNewCars;
  }

  public int getNumUsedCars() {
    return numUsedCars;
  }

  //***************************************************

  // return an arraylist of all Cars
  public ArrayList<Car> getAllCars() {
    ArrayList<Car> allCars = new ArrayList<Car>();
    for (int i=0; i<totalNumCars; i++)
      allCars.add(inventory[i]);
    return allCars;
  } // end getInventory

  //***************************************************

  // return an arraylist of all model names of new cars
  public ArrayList<String> getAllNewCarModels() {
    return allNewCarModels;
  } // end getAllNewCarModels

  //***************************************************

  // scan inventory to generate information
  private void generateReportData()
  {
    numNewCars = numUsedCars = 0; // initialize to 0
    allNewCarModels = new ArrayList<String>(); // initialize to empty

    // loop through inventory
    for (int i=0; i<totalNumCars; i++)
    {
      if (inventory[i] instanceof NewCar)
      {
        numNewCars++;

        // add model to allNewCarModels if not already exists
        String modelStr = inventory[i].getModel();
        if (!(allNewCarModels.contains(modelStr)))
          allNewCarModels.add(modelStr);
      }
      else if (inventory[i] instanceof UsedCar)
        numUsedCars++;
    } // end loop

  } // end reportCarNumbers

  //***************************************************

  /**
   * Fills inventory array with data from csv file.
   * columns are separated with comma ;
   * read in all 11 columns
   *
   * @param fileName  name of input text file
   * @return  number of records loaded
   * @throws IOException: any exception during file opening, reading, and closing
   */
  private int loadFromFile(String fileName)
  {
    Scanner fileIn = null;     // scanner object to connect to file
    final int NUM_COLS = 11;   // total number of columns in each line: 11
    int recordCount = 0;       // track # of records

    try {
      // open input file
      fileIn = new Scanner(new BufferedReader(new FileReader(fileName)));

      // skip first line of record headings
      fileIn.nextLine(); // read one line, but do not use

      // loop through multiple records
      while (fileIn.hasNext())
      {
        // 1. read one line containing all columns
        String line = fileIn.nextLine();

        // 2. extract each column

        // by locating comma, scan the first 10 columns
        // 11 columns, separated by 10 commas, so only loop 10 times
        // (col number starts from 1)
        String stockID = null;  // col 1
        int isNew = 0;          // is_new: 1 means new, 0 means old
        int year = 0;
        String model = null;
        String bodyStyle = null;
        String color = null;
        int cityMpg = 0;
        int highwayMpg = 0;
        int price = 0;          // MSRP for new car; price for used car
        int instantSavings = 0; // new car only: instant_savings
        int mileage = 0;        // col 11: used car only: mileage

        int fromIndex = 0;
        for (int col=1; col<NUM_COLS; col++)
        {
          int index = line.indexOf(',', fromIndex);
          String oneCol = line.substring(fromIndex, index);

          fromIndex = index+1;

          switch (col) {
          case 1: // col 1: stock id
            stockID = oneCol;
            break;
          case 2: // is_new: 1 means new, 0 means old
            isNew = Integer.parseInt(oneCol);
            break;
          case 3: // year
            year = Integer.parseInt(oneCol);
            break;
          case 4: // model
            model = oneCol;
            break;
          case 5: // body style
            bodyStyle = oneCol;
            break;
          case 6: // color
            color = oneCol;
            break;
          case 7: // city_mpg
            cityMpg = Integer.parseInt(oneCol);
            break;
          case 8: // highway_mpg
            highwayMpg = Integer.parseInt(oneCol);
            break;
          case 9: // MSRP for new car/price for used car
            price = Integer.parseInt(oneCol);
            break;
          case 10: // new car only: instant_savings
          if (!oneCol.isEmpty()) // only parse if not empty
            instantSavings = Integer.parseInt(oneCol);
            break;
          } // end switch

        } // end for loop
        // last column is mileage info (used car only)
        String lastCol = line.substring(fromIndex);
        if (!lastCol.isEmpty()) // only parse if not empty
          mileage = Integer.parseInt(lastCol);

        // 3. create new/used Car object and add to array
        if (isNew == 1) // new car
        {
          // ADD CODE #4:
          // 1. create a new car object using the data just read out of file
          // 2. add it to the first empty spot in instance data member Car array (inventory)
          NewCar car = new NewCar(stockID, year, model, bodyStyle, color, cityMpg, highwayMpg, price, instantSavings);
          
          inventory[totalNumCars] = (car);
          totalNumCars++;
        }
        else // used car
        {
          UsedCar car = new UsedCar(stockID, year, model, bodyStyle, color, cityMpg, highwayMpg, price, mileage);
          // ADD CODE #5
          // 1. create a used car object using the data just read out of file
          // 2. add it to the first empty spot in instance data member Car array (inventory)
          inventory[totalNumCars] = (car);
          totalNumCars++;
        }
        // 4. end reading one record. increment record counter
        recordCount++;

        // end one record
      }// end while: reading all records

    } // end try block
    catch (IOException ioe)
    {
      System.out.println("Error reading data/accident.csv file: " + ioe);
    }
    finally // close file
    {
      if ( fileIn != null)
      {  // close if was connected to a file
        fileIn.close();
      }
    } // end try-catch-finally block
    // end file input

    return recordCount;
  }// end loadFromFile

} // end class Dealership