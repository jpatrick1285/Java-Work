  
import java.util.Scanner;
public class V5 {

  public static void main(String[] args) {
    boolean isValid;
    Scanner stdIn = new Scanner(System.in);
    double dividend = 0.0;
    int divisor = 0;
    do 
    {
      isValid = true;
      System.out.print("Enter dividend: ");
      if(stdIn.hasNextDouble())
      {
        dividend = stdIn.nextDouble();
      }
      else
      {
        stdIn.next();
        System.out.println("Invalid dividend");
        isValid = false;
      }
    } while(!isValid);
    
    do 
    {
      isValid = true;
      System.out.print("Enter divisor: ");
      if(stdIn.hasNextInt())
      {
        divisor = stdIn.nextInt();
        if(divisor == 0)
        {
          System.out.println("Input error: divisor can't be zero. Please input again.");
          isValid = false;
        }
      }
      else
      {
        stdIn.next();
        System.out.println("Invalid divisor");
        isValid = false;
      }
    } while(!isValid);

    System.out.println("The result of the division is: " + dividend + " / " + divisor + " = " + dividend / divisor);
    
    stdIn.close();
  }//end main
}//end class V5
