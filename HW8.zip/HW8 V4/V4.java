import java.util.Scanner;
public class V4 {

  public static void main(String[] args) {
   boolean isValid = true;
   Scanner stdIn = new Scanner(System.in);
   double dividend = 0;
   int divisor = 0;
   do {
     isValid = true;
     System.out.print("Enter dividend: "); 
   try
   {
     dividend = Double.parseDouble(stdIn.next());
   }
   catch(NumberFormatException NFE)
   {
     isValid = false;
     System.out.println("Please enter valid number.");
   }

  }while (!isValid);
   do {
     isValid = true;
     System.out.print("Enter divisor: "); 
     try
     {
       divisor = Integer.parseInt(stdIn.next());
       if (divisor == 0)
       {
         isValid = false;
         System.out.println("Input error: divisor can't be zero. Please input again.");
       }
     }
     catch(NumberFormatException  NFE)
     {
       isValid = false;
       System.out.println("Please enter valid number.");
     }

    }while (!isValid);
    
   System.out.println("The result of the division is: " + dividend + " / " + divisor + " = " + dividend / divisor);
   
   stdIn.close();
  }// end main   
}// end class V4
