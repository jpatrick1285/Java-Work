public class isValidISBN{

public static boolean isValidISBN(String isbn) {
  { 
    int sum, i; 
    char d; 

    if (isbn.length() != 10) 
    return false; 

    d = isbn.charAt(9); 
    if (Character.toUpperCase(d) == 'X') 
    sum = 10; 
    else if (Character.isDigit(d)) 
    sum = Character.digit(d, 10); 
    else 
    return false; 

    for (i = 8; i >= 0; i--) 
    { 
    d = isbn.charAt(i); 
    if (Character.isDigit(d)) 
    sum += (10 - i) * Character.digit(d, 10); 
    else 
    return false; 
    } 

    return (sum % 11 == 0); 
    } 
}
}
