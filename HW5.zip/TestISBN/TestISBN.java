
public class TestISBN {
  public static void main(String[] args)
  {
  
  String isbn = "0-7645-2641-3";
  System.out.print(isbn + ":");
  isValidISBN(isbn);
  System.out.println();
  String isbn2 = "0 7645 26413";
  System.out.print(isbn2 + ":");
  isValidISBN(isbn2);
  System.out.println();
  String isbn3 = "978-032149805X";
  System.out.print(isbn3 + ":");
  isValidISBN(isbn3);
  System.out.println();
  String isbn4 = "0321498054";
  System.out.print(isbn4 + ":");
  isValidISBN(isbn4);
  System.out.println();

  String isbn5 =  "03214";
  System.out.print(isbn5 + ":");
  isValidISBN(isbn5);
  System.out.println();
  String isbn6 = "X978-032149805";
  System.out.print(isbn6 + ":");
  isValidISBN(isbn6);
  System.out.println();
  String isbn7 = "0-7645-2641-3X";
  System.out.print(isbn7 + ":");
  isValidISBN(isbn7);
  System.out.println();
  String isbn8 =  "0 7645 26413 23453";
  System.out.print(isbn8 + ":");
  isValidISBN(isbn8);
  System.out.println();
  String isbn9 = "97%8-032149805B";
  System.out.print(isbn9 + ":");
  isValidISBN(isbn9);
  System.out.println();

 
  }


public static boolean isValidISBN(String isbn) {
  { 
    boolean result = true;
    int counter = 0;
    
    for(int i =0; i<isbn.length(); i++)
    {
      
    if(isbn.charAt(i) == ' ' || isbn.charAt(i) == '-')
    {
      counter ++;
    }
    
    if(Character.isLetter(isbn.charAt(i)))
    {
      result = false;
    }
    
    if((isbn.charAt(isbn.length()-1)== 'X' && isbn.length() - counter == 13))
    {
      result = true;
    }
    }
    if (isbn.length() == 10|| isbn.length() == 13) 
    {
    result = true; 
    }
    
    else 
    {
      
      if((isbn.length() - counter == 10 && result != false || isbn.length() - counter == 13 && result != false))
      {
        result = true;
      }
      
      else
      {
        result = false;
      }
    }
    
    System.out.println(result);
    return result;
  
}
}
}

