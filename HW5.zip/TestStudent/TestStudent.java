
//TestStudent.java (exercise 2)
//HW5
//create ArrayList of Students and manipulate the Student objects

import java.util.ArrayList;

public class TestStudent
{
 public static void main(String[] args)
 {
   ArrayList<Student> cs219 = new ArrayList<>();

   // add student objects
   cs219.add(new Student("Mary D. Brown", 0));
   cs219.add(new Student("Tracy Smith", 7));
   cs219.add(new Student("David Hank", 2));
   cs219.add(new Student("Tom Schmidt", 8));
   cs219.add(new Student("Ted Carpenter", 0));

   // find and print out # of students with perfect attendance (0 absences)
   // record and print out the names of students who have had more than 6 absences in a String ArrayList (declare it yourself)
   // ADD CODE #1
   ArrayList<String> absence = new ArrayList<>();
   int counter = 0;
   for (Student j: cs219)
   {
     if(j.getAbsenceCount() == 0)
     {
       counter ++;
     }
     else if(j.getAbsenceCount()>= 6)
     {
       absence.add(j.getName());
     }
     
   }
   // print out results
   // ADD CODE #2
   System.out.print("The # of students with perfect attendance: ");
   System.out.println(counter);
   
   System.out.println("Students missed 6 or more classes: " + absence);
 } // end main

} // end class TestStudent
