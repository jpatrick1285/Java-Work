/**********************************************************
* ColorChangingButton.java
* CS219
* Jesse Patrick
* This program allows the user to change the color of a button
* and list out the colors the button changes into. 
**********************************************************/
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

public class ColorChangingButton extends JFrame
{
  private static final int WIDTH = 250;
  private static final int HEIGHT = 300;
  String message = "The background color of the button will \n" + "change randomly amoung \nRed, White, Yellow, Green, Blue" + "\nevery time the button is pressed.";// message for first text area
  JTextArea promptArea = new JTextArea(message);// text area with message inside
  JButton colorChangingButton = new JButton("Change Colors");//toggle button 
  JTextArea colorListArea = new JTextArea(8,15);// sets size of area for text
public ColorChangingButton()
{
  setTitle("Color Changing Button");
  setVisible(true);
  setSize(WIDTH, HEIGHT);
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  setLocationRelativeTo(null);
  setLayout(new FlowLayout());
  add(promptArea);
  promptArea.setEditable(false);
  
  add(colorChangingButton);
  add(colorListArea);
  colorChangingButton.addActionListener(new Listener());
}// end ColorChangingButton constructor 

  //*******************************************************
  // event handling 
  private class Listener implements ActionListener
  {
    public void actionPerformed(ActionEvent e)
    {
      // randomizes between colors
      if(Math.random()>=0.8) 
      {
        colorChangingButton.setBackground(Color.GREEN);
        colorListArea.append("Green\n");
    
      }
      else if(Math.random()>= 0.6)
      {
        colorChangingButton.setBackground(Color.YELLOW);
        colorListArea.append("Yellow\n");

      }
      else if(Math.random()>= 0.4)
      {
        colorChangingButton.setBackground(Color.RED);
        colorListArea.append("Red\n");
      }
      else if(Math.random()>= 0.2)
      {
        colorChangingButton.setBackground(Color.WHITE);
        colorListArea.append("White\n");
      }
      else
      {
        colorChangingButton.setBackground(Color.BLUE);
        colorListArea.append("Blue\n");
      }// end actionPerformed
      
    } // end class Listener
  }

  //*******************************************************
  public static void main(String[] args) 
  {
    new ColorChangingButton();
  }
}// end class ColorChangingButton

