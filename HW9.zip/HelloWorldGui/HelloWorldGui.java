/**********************************************************
* HelloWorldGui.java
* CS219
* Jesse Patrick
* This program is used to understand a GUI can be done in 
* in the main as well. 
**********************************************************/

import javax.swing.JFrame; 
public class HelloWorldGui extends JFrame
{
  public static void main(String[] args) {  
    JFrame frame = new JFrame("Hello World");
    frame.setVisible(true);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.setSize(250,10);

  }// end main
}// end HelloWorldGui 

