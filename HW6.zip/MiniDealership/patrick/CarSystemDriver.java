package patrick;

public class CarSystemDriver {

  public static void main(String[] args) {
    // TODO Auto-generated method stub
    NewCar new1 = new NewCar(8000.33, "silver");
    NewCar new2 = new NewCar(8000.33, "silver");
    if(new1.equals(new2))
    {
      System.out.println("New Car 1: " + new1.toString());
    }
    UsedCar used1 = new UsedCar(2500, 100000);
    UsedCar used2 = new UsedCar(2500, 100000);
    if(used1.equals(used2))
    {
      System.out.println("Used Car 1: " + used1.toString());
    }
  }

}
