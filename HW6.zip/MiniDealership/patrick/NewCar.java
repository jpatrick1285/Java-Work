package patrick;

public class NewCar extends Car {
private String color = "";

public NewCar()
{
  
}
public NewCar(double price, String color)
{
  super(price);
  this.color = color;
}
public boolean equals(NewCar otherCar)
{
  if(otherCar == null)
  {
    return false;
  }
  else
  {
    return getPrice() == otherCar.getPrice() && color.equals(otherCar.color);
  }
}
public String toString()
{
  return String.format( "$" + "%,.2f, %s", getPrice(), "Color = " + color);
}
}
