package patrick;

public class UsedCar extends Car{

  private int mileage = 0;
  
  public UsedCar() 
  {
    
  }
  public UsedCar(double price, int mileage)
  {
    super(price);
    this.mileage = mileage;
  }
  public boolean equals(UsedCar otherCar)
  {
    if(otherCar == null)
    {
      return false;
    }
    else
    {
      return getPrice() == otherCar.getPrice() && mileage == otherCar.mileage;
    }
}
  public String toString()
  {
    
    return String.format( "$" + "%,.2f, %,.2f", getPrice(), (double)mileage);
    
  }
}
