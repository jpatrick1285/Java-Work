package patrick;

public class Car {
private double price = 0; 

public Car(double cost)
{
  price = cost*2;

}
public double getPrice(){
  
  return this.price;
}
public Car()
{
}
}
